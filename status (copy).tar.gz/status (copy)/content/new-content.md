---
title: "New Content"
date: 2022-07-26T17:04:57+05:30
tags: [excited, bored]
---

Oooh hoo, I am going to make a website for statuses.