---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
tags: []
---

{{< admonition type=info title="Comments" open=true >}}
If you have anything to comment about this post, you can mail me at [comments@blackpiratex.com](mailto:comments@blackpiratex.com), I'll be waiting for your email.
{{< /admonition >}}

[Edit this page](https://github.com/blackpiratelive/blog/blob/main/content/posts/{{.Name}}.md)
